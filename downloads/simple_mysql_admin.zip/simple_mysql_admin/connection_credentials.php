<?php
 $hostname = 'localhost'; // Or IP address (e.g., $hostname = '127.0.0.1';).
 $username = 'root';
 $password = '';
