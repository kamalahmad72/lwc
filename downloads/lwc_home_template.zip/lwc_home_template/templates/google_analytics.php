<?php
/* -------------------- INTRODUCTION -------------------- */

/* File: /web_server_root_directory/templates/google_analytics.php.
 * Purpose: LWC Home Google Analytics HTML.
 * Used in: Web page files based on /web_server_root_directory/templates/web_page.php.
 * Last reviewed/updated: 24 May 2018.
 * Published: 15 May 2018.
 * NOTE: Copy changes to google_analytics.php and google_analytics.js. */
return
 "<!-- Replace this code with your Google Analytics code. -->";
