<?php
/* -------------------- INTRODUCTION -------------------- */

/* File: /web_server_root_directory/files_demo/index_toc.php.
 * Purpose: Web page table of contents.
 * Used in: /web_server_root_directory/files_demo/index.php.
 * Last reviewed/updated: 09 Feb 2017.
 * Published: 21 Sep 2016. */
return
    "<div>/web_server_root_directory/files_demo/index_toc.php</div>";
