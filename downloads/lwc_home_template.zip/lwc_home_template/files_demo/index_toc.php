<?php
/* -------------------- INTRODUCTION -------------------- */

/* File: /web_server_root_directory/files_demo/index_toc.php.
 * Purpose: Web page table of contents.
 * Used in: /web_server_root_directory/files_demo/index.php.
 * Last reviewed/updated: 24 May 2018.
 * Published: 21 Sep 2016. */
return
    "<div>This content via <span class='filename'>/web_server_root_directory/files_demo/index_toc.php</span>.</div>";
